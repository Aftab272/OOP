import React, { useState } from 'react';
import { Plus, Search, Wrench, Clock, CheckCircle, AlertCircle } from 'lucide-react';

const Repairs = () => {
  const [repairs, setRepairs] = useState([
    {
      id: 1,
      ticketNumber: 'REP-001',
      customerName: 'John Doe',
      customerPhone: '+1 234 567 8900',
      device: 'iPhone 15',
      issue: 'Screen replacement',
      status: 'pending',
      dateCreated: '2023-10-20',
      estimatedCompletion: '2023-10-22',
      cost: 150,
      notes: 'Customer reported cracked screen after drop'
    },
    {
      id: 2,
      ticketNumber: 'REP-002',
      customerName: 'Jane Smith',
      customerPhone: '+1 234 567 8901',
      device: 'Samsung Galaxy S24',
      issue: 'Battery replacement',
      status: 'in-progress',
      dateCreated: '2023-10-18',
      estimatedCompletion: '2023-10-20',
      cost: 80,
      notes: 'Battery draining quickly, needs replacement'
    },
    {
      id: 3,
      ticketNumber: 'REP-003',
      customerName: 'Mike Johnson',
      customerPhone: '+1 234 567 8902',
      device: 'MacBook Air',
      issue: 'Keyboard repair',
      status: 'completed',
      dateCreated: '2023-10-15',
      estimatedCompletion: '2023-10-17',
      cost: 200,
      notes: 'Several keys not working properly'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-600" />;
      case 'in-progress':
        return <AlertCircle className="w-4 h-4 text-blue-600" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      default:
        return <Clock className="w-4 h-4 text-gray-600" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'in-progress':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredRepairs = repairs.filter(repair => {
    const matchesSearch = repair.ticketNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         repair.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         repair.device.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || repair.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const AddRepairModal = ({ onClose, onSave }) => {
    const [formData, setFormData] = useState({
      ticketNumber: `REP-${String(repairs.length + 1).padStart(3, '0')}`,
      customerName: '',
      customerPhone: '',
      device: '',
      issue: '',
      estimatedCompletion: '',
      cost: '',
      notes: ''
    });

    const handleSubmit = (e) => {
      e.preventDefault();
      onSave({
        ...formData,
        id: Date.now(),
        status: 'pending',
        dateCreated: new Date().toISOString().split('T')[0],
        cost: parseFloat(formData.cost)
      });
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-6 w-full max-w-md">
          <h3 className="text-lg font-semibold mb-4">Create Repair Ticket</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Ticket Number</label>
              <input
                type="text"
                value={formData.ticketNumber}
                onChange={(e) => setFormData({...formData, ticketNumber: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded-lg bg-gray-100"
                readOnly
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Customer Name</label>
                <input
                  type="text"
                  value={formData.customerName}
                  onChange={(e) => setFormData({...formData, customerName: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Phone</label>
                <input
                  type="tel"
                  value={formData.customerPhone}
                  onChange={(e) => setFormData({...formData, customerPhone: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Device</label>
              <input
                type="text"
                value={formData.device}
                onChange={(e) => setFormData({...formData, device: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="e.g., iPhone 15, Samsung Galaxy S24"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Issue Description</label>
              <textarea
                value={formData.issue}
                onChange={(e) => setFormData({...formData, issue: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows="3"
                placeholder="Describe the problem..."
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Estimated Completion</label>
                <input
                  type="date"
                  value={formData.estimatedCompletion}
                  onChange={(e) => setFormData({...formData, estimatedCompletion: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Estimated Cost ($)</label>
                <input
                  type="number"
                  value={formData.cost}
                  onChange={(e) => setFormData({...formData, cost: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Additional Notes</label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows="2"
                placeholder="Any additional information..."
              />
            </div>
            <div className="flex gap-2 pt-4">
              <button
                type="submit"
                className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
              >
                Create Ticket
              </button>
              <button
                type="button"
                onClick={onClose}
                className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  const updateRepairStatus = (id, newStatus) => {
    setRepairs(repairs.map(repair =>
      repair.id === id ? { ...repair, status: newStatus } : repair
    ));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Repair Management</h1>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          New Repair Ticket
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Repairs</p>
              <p className="text-3xl font-bold text-gray-900">{repairs.length}</p>
            </div>
            <Wrench className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Pending</p>
              <p className="text-3xl font-bold text-yellow-600">
                {repairs.filter(r => r.status === 'pending').length}
              </p>
            </div>
            <Clock className="w-8 h-8 text-yellow-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">In Progress</p>
              <p className="text-3xl font-bold text-blue-600">
                {repairs.filter(r => r.status === 'in-progress').length}
              </p>
            </div>
            <AlertCircle className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Completed</p>
              <p className="text-3xl font-bold text-green-600">
                {repairs.filter(r => r.status === 'completed').length}
              </p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-64">
            <div className="relative">
              <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search by ticket, customer, or device..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          <div className="min-w-48">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="in-progress">In Progress</option>
              <option value="completed">Completed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Repairs List */}
      <div className="space-y-4">
        {filteredRepairs.map((repair) => (
          <div key={repair.id} className="bg-white rounded-lg shadow p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-lg font-semibold">{repair.ticketNumber}</h3>
                  {getStatusIcon(repair.status)}
                </div>
                <p className="text-gray-600">{repair.customerName} - {repair.customerPhone}</p>
                <p className="text-sm text-gray-500">{repair.device}</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-green-600">${repair.cost}</p>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(repair.status)}`}>
                  {repair.status.charAt(0).toUpperCase() + repair.status.slice(1).replace('-', ' ')}
                </span>
              </div>
            </div>
            
            <div className="border-t pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                <div>
                  <p className="text-sm font-medium text-gray-600">Issue:</p>
                  <p className="text-sm">{repair.issue}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">Timeline:</p>
                  <p className="text-sm">Created: {repair.dateCreated}</p>
                  <p className="text-sm">Est. Completion: {repair.estimatedCompletion}</p>
                </div>
              </div>
              
              {repair.notes && (
                <div className="mb-3">
                  <p className="text-sm font-medium text-gray-600">Notes:</p>
                  <p className="text-sm">{repair.notes}</p>
                </div>
              )}
              
              <div className="flex gap-2">
                {repair.status === 'pending' && (
                  <button
                    onClick={() => updateRepairStatus(repair.id, 'in-progress')}
                    className="px-3 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700"
                  >
                    Start Repair
                  </button>
                )}
                {repair.status === 'in-progress' && (
                  <button
                    onClick={() => updateRepairStatus(repair.id, 'completed')}
                    className="px-3 py-1 text-xs bg-green-600 text-white rounded hover:bg-green-700"
                  >
                    Mark Complete
                  </button>
                )}
                <button className="px-3 py-1 text-xs bg-gray-200 text-gray-700 rounded hover:bg-gray-300">
                  View Details
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {showAddModal && (
        <AddRepairModal
          onSave={(data) => {
            setRepairs([...repairs, data]);
            setShowAddModal(false);
          }}
          onClose={() => setShowAddModal(false)}
        />
      )}
    </div>
  );
};

export default Repairs;