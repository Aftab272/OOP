import React, { useState } from 'react';
import { Plus, Search, Package, Calendar, DollarSign } from 'lucide-react';

const Purchases = () => {
  const [purchases, setPurchases] = useState([
    {
      id: 1,
      invoiceNumber: 'PO-001',
      supplier: 'Tech Distributor Inc.',
      date: '2023-10-15',
      total: 15000,
      status: 'completed',
      items: [
        { name: 'iPhone 15', quantity: 10, unitPrice: 900, total: 9000 },
        { name: 'iPad Pro', quantity: 5, unitPrice: 800, total: 4000 },
        { name: 'AirPods Pro', quantity: 20, unitPrice: 200, total: 4000 }
      ]
    },
    {
      id: 2,
      invoiceNumber: 'PO-002',
      supplier: 'Mobile World Suppliers',
      date: '2023-10-18',
      total: 22000,
      status: 'pending',
      items: [
        { name: 'Samsung Galaxy S24', quantity: 15, unitPrice: 850, total: 12750 },
        { name: 'Galaxy Watch', quantity: 10, unitPrice: 350, total: 3500 },
        { name: 'Accessories Bundle', quantity: 25, unitPrice: 50, total: 1250 }
      ]
    }
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredPurchases = purchases.filter(purchase =>
    purchase.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    purchase.supplier.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const AddPurchaseModal = ({ onClose, onSave }) => {
    const [formData, setFormData] = useState({
      invoiceNumber: '',
      supplier: '',
      date: new Date().toISOString().split('T')[0],
      items: [{ name: '', quantity: 1, unitPrice: 0 }]
    });

    const addItem = () => {
      setFormData({
        ...formData,
        items: [...formData.items, { name: '', quantity: 1, unitPrice: 0 }]
      });
    };

    const updateItem = (index, field, value) => {
      const newItems = [...formData.items];
      newItems[index][field] = value;
      setFormData({ ...formData, items: newItems });
    };

    const handleSubmit = (e) => {
      e.preventDefault();
      const total = formData.items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
      onSave({ ...formData, total, status: 'pending', id: Date.now() });
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-96 overflow-y-auto">
          <h3 className="text-lg font-semibold mb-4">Add Purchase Order</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Invoice Number</label>
                <input
                  type="text"
                  value={formData.invoiceNumber}
                  onChange={(e) => setFormData({...formData, invoiceNumber: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Date</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({...formData, date: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Supplier</label>
              <input
                type="text"
                value={formData.supplier}
                onChange={(e) => setFormData({...formData, supplier: e.target.value})}
                className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Items</label>
              {formData.items.map((item, index) => (
                <div key={index} className="grid grid-cols-4 gap-2 mb-2">
                  <input
                    type="text"
                    placeholder="Product name"
                    value={item.name}
                    onChange={(e) => updateItem(index, 'name', e.target.value)}
                    className="p-2 border border-gray-300 rounded-lg"
                    required
                  />
                  <input
                    type="number"
                    placeholder="Quantity"
                    value={item.quantity}
                    onChange={(e) => updateItem(index, 'quantity', parseInt(e.target.value))}
                    className="p-2 border border-gray-300 rounded-lg"
                    required
                  />
                  <input
                    type="number"
                    placeholder="Unit Price"
                    value={item.unitPrice}
                    onChange={(e) => updateItem(index, 'unitPrice', parseFloat(e.target.value))}
                    className="p-2 border border-gray-300 rounded-lg"
                    required
                  />
                  <div className="p-2 bg-gray-100 rounded-lg flex items-center justify-center">
                    ${(item.quantity * item.unitPrice || 0).toFixed(2)}
                  </div>
                </div>
              ))}
              <button
                type="button"
                onClick={addItem}
                className="text-blue-600 text-sm hover:underline"
              >
                + Add Item
              </button>
            </div>
            <div className="flex gap-2 pt-4">
              <button
                type="submit"
                className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
              >
                Add Purchase
              </button>
              <button
                type="button"
                onClick={onClose}
                className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Purchase Management</h1>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Add Purchase
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Purchases</p>
              <p className="text-3xl font-bold text-gray-900">{purchases.length}</p>
            </div>
            <Package className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Amount</p>
              <p className="text-3xl font-bold text-gray-900">
                ${purchases.reduce((sum, p) => sum + p.total, 0).toLocaleString()}
              </p>
            </div>
            <DollarSign className="w-8 h-8 text-green-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Pending Orders</p>
              <p className="text-3xl font-bold text-gray-900">
                {purchases.filter(p => p.status === 'pending').length}
              </p>
            </div>
            <Calendar className="w-8 h-8 text-yellow-600" />
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="relative">
          <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search by invoice number or supplier..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Purchases List */}
      <div className="space-y-4">
        {filteredPurchases.map((purchase) => (
          <div key={purchase.id} className="bg-white rounded-lg shadow p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-lg font-semibold">{purchase.invoiceNumber}</h3>
                <p className="text-gray-600">{purchase.supplier}</p>
                <p className="text-sm text-gray-500">{purchase.date}</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-green-600">${purchase.total.toLocaleString()}</p>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  purchase.status === 'completed' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {purchase.status.charAt(0).toUpperCase() + purchase.status.slice(1)}
                </span>
              </div>
            </div>
            <div className="border-t pt-4">
              <h4 className="font-medium mb-2">Items:</h4>
              <div className="space-y-1">
                {purchase.items.map((item, index) => (
                  <div key={index} className="flex justify-between text-sm">
                    <span>{item.name} (x{item.quantity})</span>
                    <span>${item.total.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {showAddModal && (
        <AddPurchaseModal
          onSave={(data) => {
            setPurchases([...purchases, data]);
            setShowAddModal(false);
          }}
          onClose={() => setShowAddModal(false)}
        />
      )}
    </div>
  );
};

export default Purchases;