import React, { useState, useEffect } from 'react';
import React, { useState, useEffect } from 'react';
import { 
  DollarSign, 
  ShoppingBag, 
  Users, 
  TrendingUp,
  Package,
  AlertTriangle
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { testSupabaseConnection, getProducts } from '../services/dataService';

const Dashboard = () => {
  const [connectionStatus, setConnectionStatus] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  // Test Supabase connection on component mount
  useEffect(() => {
    const testConnection = async () => {
      setLoading(true);
      console.log('🔍 Testing Supabase connection from Dashboard...');
      
      // Test connection
      const connectionResult = await testSupabaseConnection();
      setConnectionStatus(connectionResult);
      
      // Try to fetch products
      const productsResult = await getProducts();
      if (productsResult.data) {
        setProducts(productsResult.data);
        console.log('✅ Products loaded:', productsResult.data);
      } else {
        console.error('❌ Failed to load products:', productsResult.error);
      }
      
      setLoading(false);
    };
    
    testConnection();
  }, []);
  // Sample data for charts
  const salesData = [
    { name: 'Mon', sales: 2400, revenue: 4000 },
    { name: 'Tue', sales: 1398, revenue: 3000 },
    { name: 'Wed', sales: 9800, revenue: 2000 },
    { name: 'Thu', sales: 3908, revenue: 2780 },
    { name: 'Fri', sales: 4800, revenue: 1890 },
    { name: 'Sat', sales: 3800, revenue: 2390 },
    { name: 'Sun', sales: 4300, revenue: 3490 },
  ];

  const topProducts = [
    { name: 'iPhone 15', sold: 45, revenue: 45000 },
    { name: 'Samsung Galaxy S24', sold: 32, revenue: 28800 },
    { name: 'MacBook Air', sold: 18, revenue: 25200 },
    { name: 'iPad Pro', sold: 25, revenue: 22500 },
  ];

  const stats = [
    {
      title: "Today's Revenue",
      value: "$12,543",
      change: "+12.5%",
      icon: DollarSign,
      color: "success"
    },
    {
      title: "Total Sales",
      value: "87",
      change: "+5.2%",
      icon: ShoppingBag,
      color: "primary"
    },
    {
      title: "Customers",
      value: "1,234",
      change: "+8.1%",
      icon: Users,
      color: "info"
    },
    {
      title: "Low Stock Items",
      value: "5",
      change: "-2",
      icon: Package,
      color: "warning"
    }
  ];

  return (
    <div className="container-fluid py-4">
      {/* Connection Status */}
      {connectionStatus && (
        <div className={`alert alert-${connectionStatus.success ? 'success' : 'danger'} mb-4`}>
          <h6 className="alert-heading mb-2">
            {connectionStatus.success ? '✅ Supabase Connected' : '❌ Supabase Connection Failed'}
          </h6>
          <small>
            {connectionStatus.success 
              ? `Database is live and working! Products loaded: ${products.length}`
              : `Error: ${connectionStatus.error}`
            }
          </small>
        </div>
      )}
      
      {/* Loading State */}
      {loading && (
        <div className="text-center py-4">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-2">Testing Supabase connection...</p>
        </div>
      )}
      {/* Header */}
      <div className="row mb-4">
        <div className="col">
          <div className="d-flex justify-content-between align-items-center">
            <h1 className="h2 fw-bold mb-0">Dashboard</h1>
            <div className="text-muted small">
              Last updated: {new Date().toLocaleString()}
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="row g-4 mb-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="col-12 col-sm-6 col-lg-3">
              <div className="card card-custom h-100">
                <div className="card-body">
                  <div className="d-flex align-items-center justify-content-between">
                    <div className="flex-grow-1">
                      <h6 className="card-subtitle mb-2 text-muted">{stat.title}</h6>
                      <h3 className="fw-bold mb-1">{stat.value}</h3>
                      <small className={`text-${stat.change.startsWith('+') ? 'success' : 'danger'}`}>
                        {stat.change} from yesterday
                      </small>
                    </div>
                    <div className={`bg-${stat.color} bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center`}
                         style={{ width: '48px', height: '48px' }}>
                      <Icon size={24} className={`text-${stat.color}`} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="row g-4 mb-4">
        {/* Sales Trend */}
        <div className="col-12 col-lg-6">
          <div className="card card-custom h-100">
            <div className="card-header bg-transparent border-bottom">
              <h5 className="card-title mb-0">Sales Trend (Last 7 Days)</h5>
            </div>
            <div className="card-body">
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={salesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="revenue" stroke="#3B82F6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Top Products */}
        <div className="col-12 col-lg-6">
          <div className="card card-custom h-100">
            <div className="card-header bg-transparent border-bottom">
              <h5 className="card-title mb-0">Top Selling Products</h5>
            </div>
            <div className="card-body">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={topProducts}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="sold" fill="#10B981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activities & Alerts */}
      <div className="row g-4">
        {/* Recent Sales */}
        <div className="col-12 col-lg-6">
          <div className="card card-custom h-100">
            <div className="card-header bg-transparent border-bottom">
              <h5 className="card-title mb-0">Recent Sales</h5>
            </div>
            <div className="card-body">
              <div className="list-group list-group-flush">
                {[
                  { id: '#1234', customer: 'John Doe', amount: '$250.00', time: '10 mins ago' },
                  { id: '#1235', customer: 'Jane Smith', amount: '$450.00', time: '25 mins ago' },
                  { id: '#1236', customer: 'Mike Johnson', amount: '$320.00', time: '1 hour ago' },
                  { id: '#1237', customer: 'Sarah Wilson', amount: '$180.00', time: '2 hours ago' },
                ].map((sale) => (
                  <div key={sale.id} className="list-group-item border-0 px-0 d-flex justify-content-between align-items-center">
                    <div>
                      <h6 className="mb-1 fw-semibold">{sale.id}</h6>
                      <p className="mb-0 text-muted small">{sale.customer}</p>
                    </div>
                    <div className="text-end">
                      <span className="fw-semibold text-success">{sale.amount}</span>
                      <div className="text-muted small">{sale.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Low Stock Alerts */}
        <div className="col-12 col-lg-6">
          <div className="card card-custom h-100">
            <div className="card-header bg-transparent border-bottom">
              <h5 className="card-title mb-0 d-flex align-items-center">
                <AlertTriangle size={20} className="text-warning me-2" />
                Low Stock Alerts
              </h5>
            </div>
            <div className="card-body">
              <div className="list-group list-group-flush">
                {[
                  { name: 'iPhone Cases', stock: 5, min: 20 },
                  { name: 'USB Cables', stock: 8, min: 25 },
                  { name: 'Screen Protectors', stock: 3, min: 15 },
                  { name: 'Wireless Chargers', stock: 7, min: 20 },
                ].map((item, index) => (
                  <div key={index} className="list-group-item border-0 px-0 d-flex justify-content-between align-items-center">
                    <div>
                      <h6 className="mb-1 fw-semibold">{item.name}</h6>
                      <p className="mb-0 text-muted small">Min stock: {item.min}</p>
                    </div>
                    <div className="text-end">
                      <span className="badge bg-danger">{item.stock} left</span>
                      <div className="mt-1">
                        <button className="btn btn-sm btn-outline-primary">Reorder</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;