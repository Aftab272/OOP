import React, { useState } from 'react';
import { RotateCcw, Search, Calendar, Package } from 'lucide-react';

const Returns = () => {
  const [returns, setReturns] = useState([
    {
      id: 1,
      returnNumber: 'RET-001',
      originalInvoice: 'INV-1234',
      customerName: 'John Doe',
      date: '2023-10-20',
      reason: 'Defective product',
      status: 'pending',
      items: [
        { name: 'iPhone Case', quantity: 1, price: 25.00, reason: 'Cracked on arrival' }
      ],
      refundAmount: 25.00
    },
    {
      id: 2,
      returnNumber: 'RET-002',
      originalInvoice: 'INV-1235',
      customerName: 'Jane Smith',
      date: '2023-10-18',
      reason: 'Changed mind',
      status: 'approved',
      items: [
        { name: 'Wireless Charger', quantity: 1, price: 50.00, reason: 'Not compatible' }
      ],
      refundAmount: 50.00
    }
  ]);

  const [warranties] = useState([
    {
      id: 1,
      productName: 'iPhone 15',
      customerName: 'Mike Johnson',
      purchaseDate: '2023-08-15',
      warrantyPeriod: '12 months',
      status: 'active',
      expiryDate: '2024-08-15'
    },
    {
      id: 2,
      productName: 'MacBook Air',
      customerName: 'Sarah Wilson',
      purchaseDate: '2022-10-20',
      warrantyPeriod: '24 months',
      status: 'expired',
      expiryDate: '2024-10-20'
    }
  ]);

  const [activeTab, setActiveTab] = useState('returns');
  const [searchTerm, setSearchTerm] = useState('');

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'expired':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredReturns = returns.filter(ret =>
    ret.returnNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ret.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ret.originalInvoice.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredWarranties = warranties.filter(warranty =>
    warranty.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    warranty.customerName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Returns & Warranty</h1>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('returns')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'returns'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Returns
            </button>
            <button
              onClick={() => setActiveTab('warranty')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'warranty'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Warranty
            </button>
          </nav>
        </div>

        <div className="p-6">
          {/* Search */}
          <div className="mb-6">
            <div className="relative">
              <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder={`Search ${activeTab}...`}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Returns Tab */}
          {activeTab === 'returns' && (
            <div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Returns</p>
                      <p className="text-2xl font-bold text-gray-900">{returns.length}</p>
                    </div>
                    <RotateCcw className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Pending Returns</p>
                      <p className="text-2xl font-bold text-yellow-600">
                        {returns.filter(r => r.status === 'pending').length}
                      </p>
                    </div>
                    <Calendar className="w-6 h-6 text-yellow-600" />
                  </div>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Refund Amount</p>
                      <p className="text-2xl font-bold text-green-600">
                        ${returns.reduce((sum, r) => sum + r.refundAmount, 0).toFixed(2)}
                      </p>
                    </div>
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                      <span className="text-green-600 font-bold text-sm">$</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                {filteredReturns.map((returnItem) => (
                  <div key={returnItem.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-semibold">{returnItem.returnNumber}</h3>
                        <p className="text-sm text-gray-600">
                          Original Invoice: {returnItem.originalInvoice}
                        </p>
                        <p className="text-sm text-gray-600">
                          Customer: {returnItem.customerName}
                        </p>
                        <p className="text-sm text-gray-500">Date: {returnItem.date}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-bold text-red-600">
                          -${returnItem.refundAmount.toFixed(2)}
                        </p>
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(returnItem.status)}`}>
                          {returnItem.status.charAt(0).toUpperCase() + returnItem.status.slice(1)}
                        </span>
                      </div>
                    </div>
                    
                    <div className="border-t pt-3">
                      <p className="text-sm font-medium text-gray-600 mb-1">Reason: {returnItem.reason}</p>
                      <div className="space-y-1">
                        {returnItem.items.map((item, index) => (
                          <div key={index} className="flex justify-between text-sm">
                            <span>{item.name} (x{item.quantity}) - {item.reason}</span>
                            <span>${item.price.toFixed(2)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    {returnItem.status === 'pending' && (
                      <div className="flex gap-2 mt-3">
                        <button className="px-3 py-1 text-xs bg-green-600 text-white rounded hover:bg-green-700">
                          Approve
                        </button>
                        <button className="px-3 py-1 text-xs bg-red-600 text-white rounded hover:bg-red-700">
                          Reject
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Warranty Tab */}
          {activeTab === 'warranty' && (
            <div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Warranties</p>
                      <p className="text-2xl font-bold text-gray-900">{warranties.length}</p>
                    </div>
                    <Package className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Active Warranties</p>
                      <p className="text-2xl font-bold text-green-600">
                        {warranties.filter(w => w.status === 'active').length}
                      </p>
                    </div>
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                      <span className="text-green-600 font-bold text-sm">✓</span>
                    </div>
                  </div>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Expired Warranties</p>
                      <p className="text-2xl font-bold text-red-600">
                        {warranties.filter(w => w.status === 'expired').length}
                      </p>
                    </div>
                    <div className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center">
                      <span className="text-red-600 font-bold text-sm">✕</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Product
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Customer
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Purchase Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Warranty Period
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Expiry Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredWarranties.map((warranty) => (
                      <tr key={warranty.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{warranty.productName}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{warranty.customerName}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {warranty.purchaseDate}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {warranty.warrantyPeriod}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {warranty.expiryDate}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(warranty.status)}`}>
                            {warranty.status.charAt(0).toUpperCase() + warranty.status.slice(1)}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Returns;