import React, { useState } from 'react';
import { Settings as SettingsIcon, Save, CreditCard, Percent, DollarSign } from 'lucide-react';

const Settings = () => {
  const [settings, setSettings] = useState({
    store: {
      name: 'My POS Store',
      address: '123 Main Street, City, State 12345',
      phone: '+1 234 567 8900',
      email: 'store@example.com',
      currency: 'USD',
      taxRate: 10,
      receiptMessage: 'Thank you for your business!'
    },
    payment: {
      methods: {
        cash: true,
        creditCard: true,
        debitCard: true,
        upi: true,
        bankTransfer: false
      },
      cardProcessing: {
        merchantId: '',
        terminalId: '',
        gateway: 'stripe'
      }
    },
    inventory: {
      lowStockThreshold: 10,
      autoReorder: false,
      trackSerial: true,
      barcodeFormat: 'CODE128'
    },
    receipt: {
      printAutomatically: true,
      emailReceipts: false,
      smsReceipts: false,
      logoUrl: '',
      footerText: 'Visit us again!'
    },
    discounts: {
      seniorDiscount: 5,
      employeeDiscount: 10,
      bulkDiscount: 15,
      loyaltyDiscount: 8
    }
  });

  const [activeTab, setActiveTab] = useState('store');

  const handleSettingChange = (section, key, value) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [key]: value
      }
    }));
  };

  const handleNestedSettingChange = (section, subsection, key, value) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [subsection]: {
          ...prev[section][subsection],
          [key]: value
        }
      }
    }));
  };

  const saveSettings = () => {
    console.log('Settings saved:', settings);
    alert('Settings saved successfully!');
  };

  const tabs = [
    { id: 'store', label: 'Store Settings', icon: SettingsIcon },
    { id: 'payment', label: 'Payment Methods', icon: CreditCard },
    { id: 'discounts', label: 'Discounts', icon: Percent },
    { id: 'inventory', label: 'Inventory', icon: DollarSign },
    { id: 'receipt', label: 'Receipt Settings', icon: DollarSign }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <button
          onClick={saveSettings}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2"
        >
          <Save className="w-4 h-4" />
          Save Settings
        </button>
      </div>

      <div className="bg-white rounded-lg shadow">
        {/* Tabs */}
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2 ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {/* Store Settings */}
          {activeTab === 'store' && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold">Store Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Store Name</label>
                  <input
                    type="text"
                    value={settings.store.name}
                    onChange={(e) => handleSettingChange('store', 'name', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Currency</label>
                  <select
                    value={settings.store.currency}
                    onChange={(e) => handleSettingChange('store', 'currency', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="USD">USD - US Dollar</option>
                    <option value="EUR">EUR - Euro</option>
                    <option value="GBP">GBP - British Pound</option>
                    <option value="PKR">PKR - Pakistani Rupee</option>
                    <option value="INR">INR - Indian Rupee</option>
                  </select>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
                  <textarea
                    value={settings.store.address}
                    onChange={(e) => handleSettingChange('store', 'address', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows="3"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                  <input
                    type="tel"
                    value={settings.store.phone}
                    onChange={(e) => handleSettingChange('store', 'phone', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input
                    type="email"
                    value={settings.store.email}
                    onChange={(e) => handleSettingChange('store', 'email', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Tax Rate (%)</label>
                  <input
                    type="number"
                    value={settings.store.taxRate}
                    onChange={(e) => handleSettingChange('store', 'taxRate', parseFloat(e.target.value))}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Receipt Message</label>
                  <input
                    type="text"
                    value={settings.store.receiptMessage}
                    onChange={(e) => handleSettingChange('store', 'receiptMessage', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Payment Methods */}
          {activeTab === 'payment' && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold">Payment Methods</h3>
              <div className="space-y-4">
                {Object.entries(settings.payment.methods).map(([method, enabled]) => (
                  <div key={method} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                    <span className="font-medium capitalize">{method.replace(/([A-Z])/g, ' $1').trim()}</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={enabled}
                        onChange={(e) => handleNestedSettingChange('payment', 'methods', method, e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                ))}
              </div>

              <h4 className="text-md font-semibold mt-6">Card Processing Settings</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Payment Gateway</label>
                  <select
                    value={settings.payment.cardProcessing.gateway}
                    onChange={(e) => handleNestedSettingChange('payment', 'cardProcessing', 'gateway', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="stripe">Stripe</option>
                    <option value="square">Square</option>
                    <option value="paypal">PayPal</option>
                    <option value="razorpay">Razorpay</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Merchant ID</label>
                  <input
                    type="text"
                    value={settings.payment.cardProcessing.merchantId}
                    onChange={(e) => handleNestedSettingChange('payment', 'cardProcessing', 'merchantId', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter merchant ID"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Discounts */}
          {activeTab === 'discounts' && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold">Discount Settings</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Object.entries(settings.discounts).map(([discountType, value]) => (
                  <div key={discountType}>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      {discountType.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} (%)
                    </label>
                    <input
                      type="number"
                      value={value}
                      onChange={(e) => handleSettingChange('discounts', discountType, parseFloat(e.target.value))}
                      className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      min="0"
                      max="100"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Inventory Settings */}
          {activeTab === 'inventory' && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold">Inventory Settings</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Low Stock Threshold</label>
                  <input
                    type="number"
                    value={settings.inventory.lowStockThreshold}
                    onChange={(e) => handleSettingChange('inventory', 'lowStockThreshold', parseInt(e.target.value))}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    min="0"
                  />
                  <p className="text-sm text-gray-500 mt-1">Alert when stock falls below this number</p>
                </div>

                <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                  <div>
                    <span className="font-medium">Auto Reorder</span>
                    <p className="text-sm text-gray-500">Automatically create purchase orders for low stock items</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.inventory.autoReorder}
                      onChange={(e) => handleSettingChange('inventory', 'autoReorder', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                  <div>
                    <span className="font-medium">Track Serial Numbers</span>
                    <p className="text-sm text-gray-500">Enable serial number tracking for products</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.inventory.trackSerial}
                      onChange={(e) => handleSettingChange('inventory', 'trackSerial', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Barcode Format</label>
                  <select
                    value={settings.inventory.barcodeFormat}
                    onChange={(e) => handleSettingChange('inventory', 'barcodeFormat', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="CODE128">CODE128</option>
                    <option value="EAN13">EAN13</option>
                    <option value="UPC">UPC</option>
                    <option value="QR">QR Code</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Receipt Settings */}
          {activeTab === 'receipt' && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold">Receipt Settings</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                  <div>
                    <span className="font-medium">Print Automatically</span>
                    <p className="text-sm text-gray-500">Automatically print receipt after each sale</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.receipt.printAutomatically}
                      onChange={(e) => handleSettingChange('receipt', 'printAutomatically', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                  <div>
                    <span className="font-medium">Email Receipts</span>
                    <p className="text-sm text-gray-500">Send receipts via email to customers</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.receipt.emailReceipts}
                      onChange={(e) => handleSettingChange('receipt', 'emailReceipts', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Logo URL</label>
                  <input
                    type="url"
                    value={settings.receipt.logoUrl}
                    onChange={(e) => handleSettingChange('receipt', 'logoUrl', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="https://example.com/logo.png"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Footer Text</label>
                  <textarea
                    value={settings.receipt.footerText}
                    onChange={(e) => handleSettingChange('receipt', 'footerText', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows="2"
                    placeholder="Thank you message or additional information"
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Settings;