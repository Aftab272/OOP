import React, { useState } from 'react';
import { ShoppingCart, User, Lock, AlertCircle } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import SignUp from './SignUp';

const Login = () => {
  const { signIn, loading } = useAuth();
  const [credentials, setCredentials] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showSignUp, setShowSignUp] = useState(false);


  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      console.log('Attempting to sign in with:', credentials.email);
      const { error } = await signIn(credentials.email, credentials.password);
      
      if (error) {
        console.error('Sign in error:', error);
        
        if (error.message.includes('Invalid login credentials')) {
          setError('Invalid email or password. If you just signed up, your email might need confirmation.');
        } else if (error.message.includes('Email not confirmed')) {
          setError('Please check your email and click the confirmation link, or contact admin.');
        } else if (error.message.includes('User not found')) {
          setError('No account found with this email. Please sign up first.');
        } else {
          setError(error.message || 'Login failed. Please try again.');
        }
      } else {
        console.log('Sign in successful!');
      }
    } catch (err) {
      console.error('Unexpected login error:', err);
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // Show sign up page if requested
  if (showSignUp) {
    return <SignUp onSwitchToLogin={() => setShowSignUp(false)} />;
  }



  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center" style={{
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
    }}>
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-md-6 col-lg-4">
            <div className="card shadow-lg border-0 card-custom">
              <div className="card-body p-5">
                <div className="text-center mb-4">
                  <div className="d-inline-flex align-items-center justify-content-center rounded-circle bg-primary mb-3" 
                       style={{ width: '80px', height: '80px' }}>
                    <ShoppingCart className="text-white" size={40} />
                  </div>
                  <h2 className="fw-bold text-dark mb-2">POS System</h2>
                  <p className="text-muted">Sign in to your account</p>
                </div>
                
                {error && (
                  <div className="alert alert-danger d-flex align-items-center mb-4" role="alert">
                    <AlertCircle size={16} className="me-2" />
                    <small>{error}</small>
                  </div>
                )}
                
                <form onSubmit={handleSubmit}>
                  <div className="mb-4">
                    <label className="form-label fw-medium text-dark">Email</label>
                    <div className="input-group">
                      <span className="input-group-text border-end-0 bg-light">
                        <User size={20} className="text-muted" />
                      </span>
                      <input
                        type="email"
                        className="form-control border-start-0 ps-0"
                        value={credentials.email}
                        onChange={(e) => setCredentials({...credentials, email: e.target.value})}
                        placeholder="Enter email"
                        required
                        disabled={isLoading || loading}
                      />
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <label className="form-label fw-medium text-dark">Password</label>
                    <div className="input-group">
                      <span className="input-group-text border-end-0 bg-light">
                        <Lock size={20} className="text-muted" />
                      </span>
                      <input
                        type="password"
                        className="form-control border-start-0 ps-0"
                        value={credentials.password}
                        onChange={(e) => setCredentials({...credentials, password: e.target.value})}
                        placeholder="Enter password"
                        required
                        disabled={isLoading || loading}
                      />
                    </div>
                  </div>
                  
                  <div className="d-grid mb-4">
                    <button
                      type="submit"
                      className="btn btn-primary btn-lg btn-custom"
                      disabled={isLoading || loading}
                    >
                      {isLoading || loading ? (
                        <>
                          <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                          Signing In...
                        </>
                      ) : (
                        'Sign In'
                      )}
                    </button>
                  </div>
                </form>
                
                <div className="text-center mb-4">
                  <p className="mb-2">
                    Don't have an account?{' '}
                    <button
                      type="button"
                      onClick={() => setShowSignUp(true)}
                      className="btn btn-link p-0 text-decoration-none"
                      disabled={isLoading || loading}
                    >
                      Create one here
                    </button>
                  </p>
                </div>
                
                <div className="alert alert-info" role="alert">
                  <h6 className="alert-heading mb-2">Getting Started:</h6>
                  <small>
                    1. Create an account using "Create one here"<br/>
                    2. Sign in with your email and password<br/>
                    3. Access features based on your role<br/>
                    4. Full Supabase backend integration
                  </small>
                </div>
                

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;