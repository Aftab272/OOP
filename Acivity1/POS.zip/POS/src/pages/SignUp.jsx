import React, { useState } from 'react';
import { ShoppingCart, User, Lock, Mail, AlertCircle, CheckCircle } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

const SignUp = ({ onSwitchToLogin }) => {
  const { signUp, loading } = useAuth();
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'cashier'
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setIsLoading(true);

    // Validation
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      setIsLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters long');
      setIsLoading(false);
      return;
    }

    try {
      const { error } = await signUp(formData.email, formData.password, {
        name: formData.fullName,
        role: formData.role
      });
      
      if (error) {
        setError(error.message || 'Sign up failed');
      } else {
        setSuccess('Account created successfully! Please check your email for verification.');
        // Clear form
        setFormData({
          fullName: '',
          email: '',
          password: '',
          confirmPassword: '',
          role: 'cashier'
        });
      }
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center" style={{
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
    }}>
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-md-6 col-lg-5">
            <div className="card shadow-lg border-0 card-custom">
              <div className="card-body p-5">
                <div className="text-center mb-4">
                  <div className="d-inline-flex align-items-center justify-content-center rounded-circle bg-primary mb-3" 
                       style={{ width: '80px', height: '80px' }}>
                    <ShoppingCart className="text-white" size={40} />
                  </div>
                  <h2 className="fw-bold text-dark mb-2">Create Account</h2>
                  <p className="text-muted">Join POS System</p>
                </div>
                
                {error && (
                  <div className="alert alert-danger d-flex align-items-center mb-4" role="alert">
                    <AlertCircle size={16} className="me-2" />
                    <small>{error}</small>
                  </div>
                )}

                {success && (
                  <div className="alert alert-success d-flex align-items-center mb-4" role="alert">
                    <CheckCircle size={16} className="me-2" />
                    <small>{success}</small>
                  </div>
                )}
                
                <form onSubmit={handleSubmit}>
                  <div className="mb-3">
                    <label className="form-label fw-medium text-dark">Full Name</label>
                    <div className="input-group">
                      <span className="input-group-text border-end-0 bg-light">
                        <User size={20} className="text-muted" />
                      </span>
                      <input
                        type="text"
                        className="form-control border-start-0 ps-0"
                        value={formData.fullName}
                        onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                        placeholder="Enter full name"
                        required
                        disabled={isLoading || loading}
                      />
                    </div>
                  </div>

                  <div className="mb-3">
                    <label className="form-label fw-medium text-dark">Email</label>
                    <div className="input-group">
                      <span className="input-group-text border-end-0 bg-light">
                        <Mail size={20} className="text-muted" />
                      </span>
                      <input
                        type="email"
                        className="form-control border-start-0 ps-0"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        placeholder="Enter email"
                        required
                        disabled={isLoading || loading}
                      />
                    </div>
                  </div>

                  <div className="mb-3">
                    <label className="form-label fw-medium text-dark">Role</label>
                    <select
                      className="form-select"
                      value={formData.role}
                      onChange={(e) => setFormData({...formData, role: e.target.value})}
                      disabled={isLoading || loading}
                    >
                      <option value="cashier">Cashier</option>
                      <option value="manager">Manager</option>
                      <option value="admin">Admin</option>
                    </select>
                  </div>
                  
                  <div className="mb-3">
                    <label className="form-label fw-medium text-dark">Password</label>
                    <div className="input-group">
                      <span className="input-group-text border-end-0 bg-light">
                        <Lock size={20} className="text-muted" />
                      </span>
                      <input
                        type="password"
                        className="form-control border-start-0 ps-0"
                        value={formData.password}
                        onChange={(e) => setFormData({...formData, password: e.target.value})}
                        placeholder="Enter password"
                        required
                        disabled={isLoading || loading}
                        minLength="6"
                      />
                    </div>
                  </div>

                  <div className="mb-4">
                    <label className="form-label fw-medium text-dark">Confirm Password</label>
                    <div className="input-group">
                      <span className="input-group-text border-end-0 bg-light">
                        <Lock size={20} className="text-muted" />
                      </span>
                      <input
                        type="password"
                        className="form-control border-start-0 ps-0"
                        value={formData.confirmPassword}
                        onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                        placeholder="Confirm password"
                        required
                        disabled={isLoading || loading}
                        minLength="6"
                      />
                    </div>
                  </div>
                  
                  <div className="d-grid mb-4">
                    <button
                      type="submit"
                      className="btn btn-primary btn-lg btn-custom"
                      disabled={isLoading || loading}
                    >
                      {isLoading || loading ? (
                        <>
                          <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                          Creating Account...
                        </>
                      ) : (
                        'Create Account'
                      )}
                    </button>
                  </div>
                </form>
                
                <div className="text-center">
                  <p className="mb-0">
                    Already have an account?{' '}
                    <button
                      type="button"
                      onClick={onSwitchToLogin}
                      className="btn btn-link p-0 text-decoration-none"
                      disabled={isLoading || loading}
                    >
                      Sign in here
                    </button>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUp;