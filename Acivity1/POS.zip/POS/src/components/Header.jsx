import React from 'react';
import { Menu, Bell, Search, LogOut, User, Wifi, WifiOff } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { isSupabaseConfigured } from '../lib/supabase';

const Header = ({ user, onLogout, sidebarOpen, setSidebarOpen }) => {
  const { isDemoMode } = useAuth();
  
  return (
    <header className="bg-white shadow-sm border-bottom">
      <div className="container-fluid">
        <div className="row align-items-center py-3">
          <div className="col-md-6">
            <div className="d-flex align-items-center">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="btn btn-light me-3 d-flex align-items-center justify-content-center"
                style={{ width: '40px', height: '40px' }}
              >
                <Menu size={20} />
              </button>
              
              <div className="input-group" style={{ maxWidth: '400px' }}>
                <span className="input-group-text bg-light border-end-0">
                  <Search size={18} className="text-muted" />
                </span>
                <input
                  type="text"
                  className="form-control border-start-0"
                  placeholder="Search products, customers..."
                />
              </div>
            </div>
          </div>
          
          <div className="col-md-6">
            <div className="d-flex align-items-center justify-content-end">
              {/* Connection Status */}
              <div className="me-3">
                {isDemoMode || !isSupabaseConfigured ? (
                  <span className="badge bg-warning text-dark d-flex align-items-center" title="Demo Mode - No backend connection">
                    <WifiOff size={12} className="me-1" />
                    Demo Mode
                  </span>
                ) : (
                  <span className="badge bg-success d-flex align-items-center" title="Connected to Supabase backend">
                    <Wifi size={12} className="me-1" />
                    Online
                  </span>
                )}
              </div>
              
              <div className="dropdown me-3">
                <button 
                  className="btn btn-light position-relative"
                  type="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <Bell size={20} />
                  <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style={{ fontSize: '0.6rem' }}>
                    3
                  </span>
                </button>
                <ul className="dropdown-menu dropdown-menu-end">
                  <li><h6 className="dropdown-header">Notifications</h6></li>
                  <li><a className="dropdown-item" href="#">Low stock alert: iPhone Cases</a></li>
                  <li><a className="dropdown-item" href="#">New customer registered</a></li>
                  <li><a className="dropdown-item" href="#">Daily report generated</a></li>
                  <li><hr className="dropdown-divider" /></li>
                  <li><a className="dropdown-item text-center" href="#">View all notifications</a></li>
                </ul>
              </div>
              
              <div className="dropdown">
                <button 
                  className="btn btn-light d-flex align-items-center"
                  type="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <div className="bg-primary rounded-circle d-flex align-items-center justify-content-center me-2" 
                       style={{ width: '32px', height: '32px' }}>
                    <User size={16} className="text-white" />
                  </div>
                  <div className="text-start d-none d-sm-block">
                    <div className="fw-medium" style={{ fontSize: '0.9rem' }}>
                      {user?.full_name || user?.name || 'User'}
                      {isDemoMode && <small className="text-muted"> (Demo)</small>}
                    </div>
                    <div className="text-muted" style={{ fontSize: '0.75rem' }}>{user?.role || 'User'}</div>
                  </div>
                </button>
                <ul className="dropdown-menu dropdown-menu-end">
                  <li><h6 className="dropdown-header">Account</h6></li>
                  <li><a className="dropdown-item" href="#">Profile Settings</a></li>
                  <li><a className="dropdown-item" href="#">Change Password</a></li>
                  <li><a className="dropdown-item" href="#">Preferences</a></li>
                  <li><hr className="dropdown-divider" /></li>
                  {isDemoMode ? (
                    <li>
                      <div className="dropdown-item-text">
                        <small className="text-muted">
                          <WifiOff size={12} className="me-1" />
                          Demo Mode Active
                        </small>
                      </div>
                    </li>
                  ) : (
                    <li>
                      <div className="dropdown-item-text">
                        <small className="text-success">
                          <Wifi size={12} className="me-1" />
                          Backend Connected
                        </small>
                      </div>
                    </li>
                  )}
                  <li><hr className="dropdown-divider" /></li>
                  <li>
                    <button
                      onClick={onLogout}
                      className="dropdown-item text-danger d-flex align-items-center"
                    >
                      <LogOut size={16} className="me-2" />
                      Sign Out
                    </button>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;