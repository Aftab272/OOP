import React from 'react';
import { CheckCircle, AlertCircle, Info, XCircle } from 'lucide-react';

const BootstrapDemo = () => {
  return (
    <div className="container-fluid py-4">
      <div className="row mb-4">
        <div className="col">
          <h2 className="fw-bold mb-3">Bootstrap + Tailwind Integration Demo</h2>
          <p className="text-muted">This demonstrates how Bootstrap and Tailwind CSS work together seamlessly in our POS system.</p>
        </div>
      </div>

      {/* Bootstrap Alerts with Lucide Icons */}
      <div className="row g-4 mb-4">
        <div className="col-12 col-md-6">
          <div className="alert alert-success d-flex align-items-center" role="alert">
            <CheckCircle className="me-2" size={20} />
            <div>Bootstrap and Tailwind are working perfectly together!</div>
          </div>
        </div>
        <div className="col-12 col-md-6">
          <div className="alert alert-info d-flex align-items-center" role="alert">
            <Info className="me-2" size={20} />
            <div>You can use Bootstrap components with Tailwind utilities.</div>
          </div>
        </div>
      </div>

      {/* Bootstrap Cards with Tailwind utilities */}
      <div className="row g-4 mb-4">
        <div className="col-12 col-md-4">
          <div className="card card-custom h-100">
            <div className="card-body">
              <h5 className="card-title d-flex align-items-center">
                <div className="bg-primary bg-opacity-10 rounded-circle p-2 me-2">
                  <CheckCircle className="text-primary" size={20} />
                </div>
                Bootstrap Components
              </h5>
              <p className="card-text">Cards, buttons, forms, and more Bootstrap components are fully functional.</p>
              <button className="btn btn-primary btn-custom">Bootstrap Button</button>
            </div>
          </div>
        </div>
        <div className="col-12 col-md-4">
          <div className="card card-custom h-100">
            <div className="card-body">
              <h5 className="card-title d-flex align-items-center">
                <div className="bg-success bg-opacity-10 rounded-circle p-2 me-2">
                  <AlertCircle className="text-success" size={20} />
                </div>
                Tailwind Utilities
              </h5>
              <p className="card-text">All Tailwind CSS utility classes work alongside Bootstrap classes.</p>
              <button className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg transition-colors">
                Tailwind Button
              </button>
            </div>
          </div>
        </div>
        <div className="col-12 col-md-4">
          <div className="card card-custom h-100">
            <div className="card-body">
              <h5 className="card-title d-flex align-items-center">
                <div className="bg-warning bg-opacity-10 rounded-circle p-2 me-2">
                  <Info className="text-warning" size={20} />
                </div>
                Lucide Icons
              </h5>
              <p className="card-text">Beautiful, customizable icons that work with both frameworks.</p>
              <div className="d-flex gap-2">
                <CheckCircle className="text-success" size={24} />
                <AlertCircle className="text-warning" size={24} />
                <XCircle className="text-danger" size={24} />
                <Info className="text-info" size={24} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bootstrap Form with Tailwind styling */}
      <div className="row">
        <div className="col-12 col-lg-8">
          <div className="card card-custom">
            <div className="card-header">
              <h5 className="card-title mb-0">Sample Form (Bootstrap + Tailwind)</h5>
            </div>
            <div className="card-body">
              <form>
                <div className="row g-3">
                  <div className="col-md-6">
                    <label className="form-label fw-medium">First Name</label>
                    <input type="text" className="form-control" placeholder="Enter first name" />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label fw-medium">Last Name</label>
                    <input type="text" className="form-control" placeholder="Enter last name" />
                  </div>
                  <div className="col-12">
                    <label className="form-label fw-medium">Email</label>
                    <input type="email" className="form-control" placeholder="Enter email address" />
                  </div>
                  <div className="col-12">
                    <label className="form-label fw-medium">Message</label>
                    <textarea className="form-control" rows="3" placeholder="Enter your message"></textarea>
                  </div>
                  <div className="col-12">
                    <div className="d-flex gap-2">
                      <button type="submit" className="btn btn-primary btn-custom">
                        Submit (Bootstrap)
                      </button>
                      <button type="button" className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg transition-colors">
                        Cancel (Tailwind)
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div className="col-12 col-lg-4">
          <div className="card card-custom">
            <div className="card-header">
              <h5 className="card-title mb-0">Features Available</h5>
            </div>
            <div className="card-body">
              <ul className="list-unstyled">
                <li className="d-flex align-items-center mb-2">
                  <CheckCircle className="text-success me-2" size={16} />
                  Bootstrap 5.3+ Components
                </li>
                <li className="d-flex align-items-center mb-2">
                  <CheckCircle className="text-success me-2" size={16} />
                  Tailwind CSS 3.3+ Utilities
                </li>
                <li className="d-flex align-items-center mb-2">
                  <CheckCircle className="text-success me-2" size={16} />
                  Lucide React Icons
                </li>
                <li className="d-flex align-items-center mb-2">
                  <CheckCircle className="text-success me-2" size={16} />
                  Responsive Design
                </li>
                <li className="d-flex align-items-center mb-2">
                  <CheckCircle className="text-success me-2" size={16} />
                  Custom Color Scheme
                </li>
                <li className="d-flex align-items-center">
                  <CheckCircle className="text-success me-2" size={16} />
                  Enhanced Animations
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BootstrapDemo;