import React from 'react';
import { ShoppingCart } from 'lucide-react';

const LoadingSpinner = ({ message = 'Loading...' }) => {
  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center bg-light">
      <div className="text-center">
        <div className="mb-4">
          <div className="bg-primary rounded-circle d-inline-flex align-items-center justify-content-center animate-pulse" 
               style={{ width: '80px', height: '80px' }}>
            <ShoppingCart size={40} className="text-white" />
          </div>
        </div>
        
        <div className="mb-3">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
        
        <h4 className="fw-bold text-dark mb-2">POS System</h4>
        <p className="text-muted">{message}</p>
      </div>
    </div>
  );
};

export default LoadingSpinner;