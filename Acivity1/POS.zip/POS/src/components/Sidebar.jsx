import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Truck,
  Users,
  Wrench,
  RotateCcw,
  FileText,
  Settings,
  UserCheck,
  AlertTriangle,
  Scan
} from 'lucide-react';

const Sidebar = ({ isOpen }) => {
  const location = useLocation();

  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/dashboard' },
    { icon: ShoppingCart, label: 'Billing / POS', path: '/billing' },
    { icon: Package, label: 'Inventory', path: '/inventory' },
    { icon: Truck, label: 'Purchases', path: '/purchases' },
    { icon: Users, label: 'Customers', path: '/customers' },
    { icon: Wrench, label: 'Repairs', path: '/repairs' },
    { icon: RotateCcw, label: 'Returns', path: '/returns' },
    { icon: FileText, label: 'Reports', path: '/reports' },
    { icon: Settings, label: 'Settings', path: '/settings' },
    { icon: UserCheck, label: 'Users & Roles', path: '/users' },
  ];

  return (
    <div 
      className={`bg-dark text-white d-flex flex-column transition-all ${
        isOpen ? '' : 'collapsed-sidebar'
      }`}
      style={{
        width: isOpen ? '280px' : '80px',
        minHeight: '100vh',
        transition: 'width 0.3s ease'
      }}
    >
      {/* Logo Section */}
      <div className="p-3 border-bottom border-secondary">
        <div className="d-flex align-items-center">
          <div className="bg-primary rounded d-flex align-items-center justify-content-center me-2" 
               style={{ width: '40px', height: '40px' }}>
            <ShoppingCart size={20} className="text-white" />
          </div>
          {isOpen && (
            <h4 className="fw-bold mb-0 text-white">POS System</h4>
          )}
        </div>
      </div>
      
      {/* Navigation Menu */}
      <nav className="flex-fill mt-3">
        <div className="nav nav-pills flex-column">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`nav-link text-white d-flex align-items-center py-3 px-3 mx-2 rounded ${
                  isActive 
                    ? 'active bg-primary' 
                    : 'text-white-50 hover-bg-secondary'
                }`}
                style={{
                  textDecoration: 'none',
                  transition: 'all 0.2s ease'
                }}
              >
                <Icon size={20} className="flex-shrink-0" />
                {isOpen && (
                  <span className="ms-3 fw-medium">{item.label}</span>
                )}
              </Link>
            );
          })}
        </div>
      </nav>
      
      {/* Low Stock Alert */}
      {isOpen && (
        <div className="p-3 mt-auto">
          <div className="alert alert-warning mb-0" role="alert">
            <div className="d-flex align-items-center mb-2">
              <AlertTriangle size={16} className="me-2" />
              <small className="fw-semibold mb-0">Low Stock Alert</small>
            </div>
            <small className="text-muted">5 items need restocking</small>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sidebar;