import { db, TABLES } from '../lib/supabase'

export const productService = {
  // Get all products with optional filters
  async getProducts(filters = {}) {
    try {
      const { data, error } = await db.select(
        TABLES.PRODUCTS,
        `
          *,
          categories(name)
        `,
        filters
      )
      
      if (error) throw error
      return { data, error: null }
    } catch (error) {
      console.error('Error fetching products:', error)
      return { data: null, error }
    }
  },

  // Get product by ID
  async getProduct(id) {
    try {
      const { data, error } = await db.select(
        TABLES.PRODUCTS,
        `
          *,
          categories(name)
        `,
        { id }
      ).single()
      
      if (error) throw error
      return { data, error: null }
    } catch (error) {
      console.error('Error fetching product:', error)
      return { data: null, error }
    }
  },

  // Create new product
  async createProduct(productData) {
    try {
      const { data, error } = await db.insert(TABLES.PRODUCTS, {
        ...productData,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      
      if (error) throw error
      return { data: data[0], error: null }
    } catch (error) {
      console.error('Error creating product:', error)
      return { data: null, error }
    }
  },

  // Update product
  async updateProduct(id, productData) {
    try {
      const { data, error } = await db.update(TABLES.PRODUCTS, id, {
        ...productData,
        updated_at: new Date().toISOString()
      })
      
      if (error) throw error
      return { data: data[0], error: null }
    } catch (error) {
      console.error('Error updating product:', error)
      return { data: null, error }
    }
  },

  // Delete product
  async deleteProduct(id) {
    try {
      const { error } = await db.delete(TABLES.PRODUCTS, id)
      
      if (error) throw error
      return { error: null }
    } catch (error) {
      console.error('Error deleting product:', error)
      return { error }
    }
  },

  // Get low stock products
  async getLowStockProducts() {
    try {
      const { data, error } = await supabase
        .from(TABLES.PRODUCTS)
        .select('*')
        .lte('stock', supabase.raw('min_stock'))
        .order('stock', { ascending: true })
      
      if (error) throw error
      return { data, error: null }
    } catch (error) {
      console.error('Error fetching low stock products:', error)
      return { data: null, error }
    }
  },

  // Search products
  async searchProducts(searchTerm) {
    try {
      const { data, error } = await supabase
        .from(TABLES.PRODUCTS)
        .select(`
          *,
          categories(name)
        `)
        .or(
          `name.ilike.%${searchTerm}%,` +
          `sku.ilike.%${searchTerm}%,` +
          `barcode.ilike.%${searchTerm}%`
        )
        .order('name')
      
      if (error) throw error
      return { data, error: null }
    } catch (error) {
      console.error('Error searching products:', error)
      return { data: null, error }
    }
  },

  // Update stock
  async updateStock(id, quantity, operation = 'set') {
    try {
      if (operation === 'add') {
        const { data, error } = await supabase
          .from(TABLES.PRODUCTS)
          .update({ 
            stock: supabase.raw(`stock + ${quantity}`),
            updated_at: new Date().toISOString()
          })
          .eq('id', id)
          .select()
        
        if (error) throw error
        return { data: data[0], error: null }
      } else if (operation === 'subtract') {
        const { data, error } = await supabase
          .from(TABLES.PRODUCTS)
          .update({ 
            stock: supabase.raw(`stock - ${quantity}`),
            updated_at: new Date().toISOString()
          })
          .eq('id', id)
          .select()
        
        if (error) throw error
        return { data: data[0], error: null }
      } else {
        // Set stock to specific value
        const { data, error } = await db.update(TABLES.PRODUCTS, id, {
          stock: quantity,
          updated_at: new Date().toISOString()
        })
        
        if (error) throw error
        return { data: data[0], error: null }
      }
    } catch (error) {
      console.error('Error updating stock:', error)
      return { data: null, error }
    }
  }
}

export default productService