import { auth, db, TABLES, supabase, isSupabaseConfigured } from '../lib/supabase'

export const authService = {
  // Sign up new user
  async signUp(email, password, userData = {}) {
    try {
      if (!isSupabaseConfigured) {
        throw new Error('Supabase backend not configured. Please set up your .env file or use demo mode.')
      }
      
      const { data, error } = await auth.signUp(email, password, {
        full_name: userData.name || '',
        role: userData.role || 'cashier',
        store_id: userData.storeId || null
      })
      
      if (error) throw error
      
      // Check if email confirmation is required
      if (data.user && !data.user.email_confirmed_at) {
        console.log('Email confirmation may be required')
        // In development, try to auto-confirm or provide helpful message
        return { 
          data, 
          error: null,
          message: 'Account created successfully! If sign-in fails, check your email for verification or contact admin.'
        }
      }
      
      return { data, error: null }
    } catch (error) {
      console.error('Error signing up:', error)
      return { data: null, error }
    }
  },

  // Sign in user
  async signIn(email, password) {
    try {
      if (!isSupabaseConfigured) {
        throw new Error('Supabase backend not configured. Please set up your .env file or use demo mode.')
      }
      
      const { data, error } = await auth.signIn(email, password)
      
      if (error) {
        // Provide more helpful error messages
        if (error.message.includes('Invalid login credentials')) {
          console.error('Invalid credentials or email not confirmed')
        }
        throw error
      }
      
      // Get user profile from database
      if (data.user) {
        const profile = await this.getUserProfile(data.user.id)
        return { 
          data: { 
            ...data, 
            profile: profile.data 
          }, 
          error: null 
        }
      }
      
      return { data, error: null }
    } catch (error) {
      console.error('Error signing in:', error)
      return { data: null, error }
    }
  },

  // Sign out user
  async signOut() {
    try {
      const { error } = await auth.signOut()
      if (error) throw error
      return { error: null }
    } catch (error) {
      console.error('Error signing out:', error)
      return { error }
    }
  },

  // Get current user
  async getCurrentUser() {
    try {
      const { data, error } = await auth.getUser()
      
      if (error) throw error
      
      if (data.user) {
        const profile = await this.getUserProfile(data.user.id)
        return { 
          data: { 
            ...data, 
            profile: profile.data 
          }, 
          error: null 
        }
      }
      
      return { data, error: null }
    } catch (error) {
      console.error('Error getting current user:', error)
      return { data: null, error }
    }
  },

  // Create user profile
  async createUserProfile(userId, profileData) {
    try {
      const { data, error } = await db.insert(TABLES.USERS, {
        id: userId,
        ...profileData,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      
      if (error) throw error
      return { data: data[0], error: null }
    } catch (error) {
      console.error('Error creating user profile:', error)
      return { data: null, error }
    }
  },

  // Get user profile
  async getUserProfile(userId) {
    try {
      const { data, error } = await supabase
        .from(TABLES.USERS)
        .select('*')
        .eq('id', userId)
        .single()
      
      if (error && error.code !== 'PGRST116') { // PGRST116 = no rows returned
        throw error
      }
      
      // If no profile exists, create a basic one
      if (!data) {
        const { data: userData } = await supabase.auth.getUser()
        if (userData.user) {
          const newProfile = {
            id: userId,
            email: userData.user.email,
            full_name: userData.user.user_metadata?.full_name || 'User',
            role: userData.user.user_metadata?.role || 'cashier',
            status: 'active'
          }
          
          const { data: createdProfile } = await this.createUserProfile(userId, newProfile)
          return { data: createdProfile, error: null }
        }
      }
      
      return { data, error: null }
    } catch (error) {
      console.error('Error getting user profile:', error)
      return { data: null, error }
    }
  },

  // Update user profile
  async updateUserProfile(userId, profileData) {
    try {
      const { data, error } = await db.update(TABLES.USERS, userId, {
        ...profileData,
        updated_at: new Date().toISOString()
      })
      
      if (error) throw error
      return { data: data[0], error: null }
    } catch (error) {
      console.error('Error updating user profile:', error)
      return { data: null, error }
    }
  },

  // Change password
  async changePassword(newPassword) {
    try {
      const { data, error } = await supabase.auth.updateUser({
        password: newPassword
      })
      
      if (error) throw error
      return { data, error: null }
    } catch (error) {
      console.error('Error changing password:', error)
      return { data: null, error }
    }
  },

  // Reset password
  async resetPassword(email) {
    try {
      const { data, error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`
      })
      
      if (error) throw error
      return { data, error: null }
    } catch (error) {
      console.error('Error resetting password:', error)
      return { data: null, error }
    }
  },

  // Listen to auth state changes
  onAuthStateChange(callback) {
    return auth.onAuthStateChange(async (event, session) => {
      let userData = null
      
      if (session?.user) {
        const profile = await this.getUserProfile(session.user.id)
        userData = {
          ...session,
          profile: profile.data
        }
      }
      
      callback(event, userData)
    })
  }
}

export default authService