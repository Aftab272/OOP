import { db, TABLES } from '../lib/supabase'
import { productService } from './productService'

export const salesService = {
  // Create new sale
  async createSale(saleData) {
    try {
      const { items, ...sale } = saleData
      
      // Create sale record
      const { data: saleRecord, error: saleError } = await db.insert(TABLES.SALES, {
        ...sale,
        sale_date: new Date().toISOString(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      
      if (saleError) throw saleError
      
      const saleId = saleRecord[0].id
      
      // Create sale items and update stock
      const saleItems = []
      for (const item of items) {
        // Add sale item
        const { data: saleItem, error: itemError } = await db.insert(TABLES.SALE_ITEMS, {
          sale_id: saleId,
          product_id: item.product_id,
          quantity: item.quantity,
          unit_price: item.unit_price,
          total_price: item.quantity * item.unit_price,
          created_at: new Date().toISOString()
        })
        
        if (itemError) throw itemError
        saleItems.push(saleItem[0])
        
        // Update product stock
        await productService.updateStock(item.product_id, item.quantity, 'subtract')
      }
      
      return { 
        data: { 
          sale: saleRecord[0], 
          items: saleItems 
        }, 
        error: null 
      }
    } catch (error) {
      console.error('Error creating sale:', error)
      return { data: null, error }
    }
  },

  // Get all sales with filters
  async getSales(filters = {}) {
    try {
      let query = supabase
        .from(TABLES.SALES)
        .select(`
          *,
          sale_items(
            *,
            products(name, sku)
          ),
          customers(name, email)
        `)
        .order('created_at', { ascending: false })
      
      // Apply date filters
      if (filters.startDate) {
        query = query.gte('sale_date', filters.startDate)
      }
      if (filters.endDate) {
        query = query.lte('sale_date', filters.endDate)
      }
      if (filters.customerId) {
        query = query.eq('customer_id', filters.customerId)
      }
      
      const { data, error } = await query
      
      if (error) throw error
      return { data, error: null }
    } catch (error) {
      console.error('Error fetching sales:', error)
      return { data: null, error }
    }
  },

  // Get sale by ID
  async getSale(id) {
    try {
      const { data, error } = await supabase
        .from(TABLES.SALES)
        .select(`
          *,
          sale_items(
            *,
            products(name, sku, price)
          ),
          customers(name, email, phone)
        `)
        .eq('id', id)
        .single()
      
      if (error) throw error
      return { data, error: null }
    } catch (error) {
      console.error('Error fetching sale:', error)
      return { data: null, error }
    }
  },

  // Get daily sales summary
  async getDailySummary(date = new Date().toISOString().split('T')[0]) {
    try {
      const { data, error } = await supabase
        .from(TABLES.SALES)
        .select('total_amount, payment_method, status')
        .gte('sale_date', `${date}T00:00:00`)
        .lte('sale_date', `${date}T23:59:59`)
      
      if (error) throw error
      
      const summary = {
        totalSales: data.length,
        totalRevenue: data.reduce((sum, sale) => sum + (sale.total_amount || 0), 0),
        completedSales: data.filter(sale => sale.status === 'completed').length,
        averageTransaction: data.length > 0 ? 
          data.reduce((sum, sale) => sum + (sale.total_amount || 0), 0) / data.length : 0,
        paymentMethods: data.reduce((acc, sale) => {
          acc[sale.payment_method] = (acc[sale.payment_method] || 0) + 1
          return acc
        }, {})
      }
      
      return { data: summary, error: null }
    } catch (error) {
      console.error('Error fetching daily summary:', error)
      return { data: null, error }
    }
  },

  // Get sales analytics
  async getSalesAnalytics(period = 'week') {
    try {
      let startDate = new Date()
      
      switch (period) {
        case 'week':
          startDate.setDate(startDate.getDate() - 7)
          break
        case 'month':
          startDate.setMonth(startDate.getMonth() - 1)
          break
        case 'year':
          startDate.setFullYear(startDate.getFullYear() - 1)
          break
        default:
          startDate.setDate(startDate.getDate() - 7)
      }
      
      const { data, error } = await supabase
        .from(TABLES.SALES)
        .select(`
          sale_date,
          total_amount,
          status,
          sale_items(quantity, products(name))
        `)
        .gte('sale_date', startDate.toISOString())
        .eq('status', 'completed')
        .order('sale_date')
      
      if (error) throw error
      
      // Process data for analytics
      const analytics = {
        revenue: data.reduce((sum, sale) => sum + (sale.total_amount || 0), 0),
        transactions: data.length,
        averageTransaction: data.length > 0 ? 
          data.reduce((sum, sale) => sum + (sale.total_amount || 0), 0) / data.length : 0,
        dailyBreakdown: {},
        topProducts: {}
      }
      
      // Daily breakdown
      data.forEach(sale => {
        const date = sale.sale_date.split('T')[0]
        if (!analytics.dailyBreakdown[date]) {
          analytics.dailyBreakdown[date] = { revenue: 0, transactions: 0 }
        }
        analytics.dailyBreakdown[date].revenue += sale.total_amount || 0
        analytics.dailyBreakdown[date].transactions += 1
      })
      
      // Top products
      data.forEach(sale => {
        sale.sale_items.forEach(item => {
          const productName = item.products.name
          if (!analytics.topProducts[productName]) {
            analytics.topProducts[productName] = 0
          }
          analytics.topProducts[productName] += item.quantity
        })
      })
      
      return { data: analytics, error: null }
    } catch (error) {
      console.error('Error fetching sales analytics:', error)
      return { data: null, error }
    }
  },

  // Process return
  async processReturn(saleId, returnItems, reason) {
    try {
      // Get original sale
      const { data: sale, error: saleError } = await this.getSale(saleId)
      if (saleError) throw saleError
      
      // Create return record
      const { data: returnRecord, error: returnError } = await db.insert(TABLES.RETURNS, {
        original_sale_id: saleId,
        return_reason: reason,
        return_date: new Date().toISOString(),
        status: 'pending',
        created_at: new Date().toISOString()
      })
      
      if (returnError) throw returnError
      
      // Update stock for returned items
      for (const item of returnItems) {
        await productService.updateStock(item.product_id, item.quantity, 'add')
      }
      
      return { data: returnRecord[0], error: null }
    } catch (error) {
      console.error('Error processing return:', error)
      return { data: null, error }
    }
  }
}

export default salesService