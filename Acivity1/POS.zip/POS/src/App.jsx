import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { isSupabaseConfigured } from './lib/supabase';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './pages/Dashboard';
import Billing from './pages/Billing';
import Inventory from './pages/Inventory';
import Purchases from './pages/Purchases';
import Customers from './pages/Customers';
import Repairs from './pages/Repairs';
import Returns from './pages/Returns';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import Users from './pages/Users';
import Login from './pages/Login';
import LoadingSpinner from './components/LoadingSpinner';



// Main App Component wrapped with authentication
function AppContent() {
  const { user, loading, signOut } = useAuth();
  const [sidebarOpen, setSidebarOpen] = React.useState(true);

  // Show loading spinner while checking authentication
  if (loading) {
    return <LoadingSpinner />;
  }

  // Skip login and go directly to main app
  // Create a default user if none exists
  const defaultUser = user || {
    id: 'demo-user',
    email: 'admin@pos.com',
    full_name: 'Admin User',
    role: 'admin'
  };

  // Main application layout
  return (
    <Router>
      <div className="d-flex vh-100 bg-light">
        <Sidebar isOpen={sidebarOpen} />
        <div className="flex-fill d-flex flex-column overflow-hidden">
          <Header 
            user={defaultUser}
            onLogout={signOut}
            sidebarOpen={sidebarOpen}
            setSidebarOpen={setSidebarOpen}
          />
          <main className="flex-fill overflow-auto bg-light p-0">
            <Routes>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/billing" element={<Billing />} />
              <Route path="/inventory" element={<Inventory />} />
              <Route path="/purchases" element={<Purchases />} />
              <Route path="/customers" element={<Customers />} />
              <Route path="/repairs" element={<Repairs />} />
              <Route path="/returns" element={<Returns />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/users" element={<Users />} />
            </Routes>
          </main>
        </div>
      </div>
    </Router>
  );
}

// Root App Component with Auth Provider
function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;