import { useState, useEffect } from 'react'
import { db } from '../lib/supabase'

export const useRealtimeData = (table, initialData = []) => {
  const [data, setData] = useState(initialData)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    let subscription = null

    const fetchInitialData = async () => {
      try {
        setLoading(true)
        const { data: fetchedData, error: fetchError } = await db.select(table)
        
        if (fetchError) throw fetchError
        
        setData(fetchedData || [])
        setError(null)
      } catch (err) {
        console.error(`Error fetching ${table}:`, err)
        setError(err)
      } finally {
        setLoading(false)
      }
    }

    const setupRealtimeSubscription = () => {
      subscription = db.subscribe(
        table,
        (payload) => {
          console.log(`Realtime update for ${table}:`, payload)
          
          switch (payload.eventType) {
            case 'INSERT':
              setData(prevData => [...prevData, payload.new])
              break
            case 'UPDATE':
              setData(prevData => 
                prevData.map(item => 
                  item.id === payload.new.id ? payload.new : item
                )
              )
              break
            case 'DELETE':
              setData(prevData => 
                prevData.filter(item => item.id !== payload.old.id)
              )
              break
            default:
              break
          }
        }
      )
    }

    // Fetch initial data and setup subscription
    fetchInitialData().then(() => {
      setupRealtimeSubscription()
    })

    // Cleanup subscription on unmount
    return () => {
      if (subscription) {
        db.unsubscribe(subscription)
      }
    }
  }, [table])

  const refetch = async () => {
    try {
      setLoading(true)
      const { data: fetchedData, error: fetchError } = await db.select(table)
      
      if (fetchError) throw fetchError
      
      setData(fetchedData || [])
      setError(null)
    } catch (err) {
      console.error(`Error refetching ${table}:`, err)
      setError(err)
    } finally {
      setLoading(false)
    }
  }

  return {
    data,
    loading,
    error,
    refetch
  }
}

// Hook for products with low stock alerts
export const useProducts = () => {
  const { data: products, loading, error, refetch } = useRealtimeData('products')
  
  const lowStockProducts = products.filter(
    product => product.stock <= (product.min_stock || 10)
  )

  return {
    products,
    lowStockProducts,
    loading,
    error,
    refetch
  }
}

// Hook for daily sales
export const useDailySales = () => {
  const [sales, setSales] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchDailySales = async () => {
      try {
        setLoading(true)
        const today = new Date().toISOString().split('T')[0]
        
        const { data, error: salesError } = await supabase
          .from('sales')
          .select(`
            *,
            sale_items(
              quantity,
              unit_price,
              total_price,
              products(name)
            )
          `)
          .gte('sale_date', `${today}T00:00:00`)
          .lte('sale_date', `${today}T23:59:59`)
          .order('created_at', { ascending: false })
        
        if (salesError) throw salesError
        
        setSales(data || [])
        setError(null)
      } catch (err) {
        console.error('Error fetching daily sales:', err)
        setError(err)
      } finally {
        setLoading(false)
      }
    }

    fetchDailySales()

    // Setup realtime subscription for sales
    const subscription = db.subscribe(
      'sales',
      (payload) => {
        const today = new Date().toISOString().split('T')[0]
        const saleDate = payload.new?.sale_date?.split('T')[0]
        
        if (saleDate === today) {
          if (payload.eventType === 'INSERT') {
            setSales(prevSales => [payload.new, ...prevSales])
          } else if (payload.eventType === 'UPDATE') {
            setSales(prevSales => 
              prevSales.map(sale => 
                sale.id === payload.new.id ? payload.new : sale
              )
            )
          } else if (payload.eventType === 'DELETE') {
            setSales(prevSales => 
              prevSales.filter(sale => sale.id !== payload.old.id)
            )
          }
        }
      }
    )

    return () => {
      if (subscription) {
        db.unsubscribe(subscription)
      }
    }
  }, [])

  const totalRevenue = sales.reduce((sum, sale) => sum + (sale.total_amount || 0), 0)
  const totalTransactions = sales.length

  return {
    sales,
    totalRevenue,
    totalTransactions,
    loading,
    error
  }
}

export default useRealtimeData